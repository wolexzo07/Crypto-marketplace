# jquery-mobile-keypad
Keypad for mobile

# Usage

$('#input').keyPad({
    isRandom : true
});
