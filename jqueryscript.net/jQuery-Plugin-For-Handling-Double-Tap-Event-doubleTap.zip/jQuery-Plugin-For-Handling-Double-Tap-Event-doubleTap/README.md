# jquery-doubletap

Double tap event handling for jQuery. Useful for code running on touch devices.

## Usage

	$('.foo').doubletap(function(e) {
	  console.log('bar', e);
	});
