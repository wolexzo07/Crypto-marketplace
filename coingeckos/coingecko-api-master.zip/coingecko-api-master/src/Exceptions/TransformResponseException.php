<?php

declare(strict_types=1);

namespace Codenixsv\CoinGeckoApi\Exception;

use Exception;

/**
 * Class TransformResponseException
 * @package Codenixsv\CoinGeckoApi\Exception
 */
class TransformResponseException extends Exception
{
}
