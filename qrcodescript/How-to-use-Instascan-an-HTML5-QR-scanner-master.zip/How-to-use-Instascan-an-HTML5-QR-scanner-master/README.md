# How-to-use-Instascan-an-HTML5-QR-scanner
 How to use Instascan an HTML5 QR scanner

View online complete documentation and integration <a href="https://learncodeweb.com/jquery/how-to-use-instascan-an-html5-qr-scanner/">Click Here</a>

View working example <a href="https://learncodeweb.com/demo/jquery/how-to-use-instascan-an-html5-qr-scanner/">View Demo</a>

Thank you

Regards Zaid Bin Khalid
